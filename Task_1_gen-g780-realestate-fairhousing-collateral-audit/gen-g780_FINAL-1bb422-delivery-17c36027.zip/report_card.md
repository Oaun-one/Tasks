# QC report card

Task: obi/gen-g780-realestate-fairhousing-collateral-audit
Run: delivery-17c36027 (delivery)
Generated: 2026-08-19T15:00:14.537Z

## QC script (advisory)
- Gate: **DISQUALIFIED** — 1 blocking
- Findings: 1 blocking, 1 to fix
- GLM semantic audit: 8/8 judged items verified

## Reviewer (governs)
- Decision: **Accept** — - Oracle 1.0 across all 46 verifiers, five stability repeats identical - all verifiers deterministic, no judge, so grading is reproducible - GLM 5.2 passes 5/5 → too easy, recorded in the tracker as a status, not a QC rejection - add: "verifier metadata still reads 'bulletin B1/B2'; those provisions are now RE-FH-9 §5a/§5b — descriptive wording only, no effect on assertions or grading"
- Checklist: 19/66 answered, 1 item(s) flagged for a closer look
- Verifiers: 46 reviewed, 0 to fix

## Outcome
gate DISQUALIFIED · reviewer Accept
