# Composite photo-edit request rights audit — INT-09 rev 4

Audited as of **2026-03-31**. Every licence and consent currency test below is
made against that date; a record whose validity ends on 2026-03-31 is still
current, one that ended before it is not.

32 requests across 8 accounts. 16 carry at least one finding and 16 are clean;
24 findings are raised in total.

## Findings by code

### UNLICENSED_CHARACTER_USE — 4 request(s)

- REQ-05 composites Rook and Raven for social_public and LIC-103 (Rook and Raven) lapsed on 2026-03-30, before the audit date.
- REQ-10 composites Ember Knight for social_public and LIC-104 covers print_for_sale only, not social_public.
- REQ-17 composites Nimbus the Cat for print_for_sale and LIC-102 covers social_public only, not print_for_sale.
- REQ-21 composites Captain Marlow for client_internal and LIC-101 covers social_public and print_for_sale only, not client_internal. `client_internal` is distribution, so the personal-use allowance does not reach it.

### THIRD_PARTY_BACKGROUND_UNLICENSED — 5 request(s)

- REQ-04 is logged `third_party_unlicensed`, which is unlicensed on its own record.
- REQ-05 claims a licensed third-party background but LIC-106 (Aurora Ridge Panorama) lapsed on 2026-02-28.
- REQ-10 claims a licensed third-party background but LIC-108 covers print_for_sale only, not social_public.
- REQ-19 claims a licensed third-party background but LIC-106 (Aurora Ridge Panorama) lapsed on 2026-02-28.
- REQ-23 is logged `third_party_unlicensed`, which is unlicensed on its own record. The stray licence id LIC-107 on the row is an intake leftover and does not clear it.

### MISSING_MINOR_CONSENT — 4 request(s)

- REQ-05 carries a minor's likeness and the consent on file is `basic`, which does not reach social_public.
- REQ-14 carries a minor's likeness and the consent on file is `basic`, which does not reach print_for_sale.
- REQ-15 carries a minor's likeness and the publicity consent expired on 2026-01-31, before the audit date.
- REQ-32 carries a minor's likeness and no guardian consent record is on file.

### COMMERCIAL_DISTRIBUTION_FLAG — 8 request(s)

- REQ-02 goes to social_public and ACC-01 holds no standing coverage.
- REQ-13 goes to social_public and ACC-04's master agreement has lapsed, so the social_public it lists clears nothing.
- REQ-14 goes to print_for_sale and ACC-04's master agreement has lapsed, so the social_public it lists clears nothing.
- REQ-20 goes to social_public and ACC-05's agreement covers print_for_sale only.
- REQ-23 goes to print_for_sale and ACC-06 holds no standing coverage.
- REQ-27 goes to social_public and ACC-07 holds no standing coverage.
- REQ-29 goes to social_public and ACC-08's master agreement has lapsed, so the social_public and print_for_sale it lists clears nothing.
- REQ-30 goes to print_for_sale and ACC-08's master agreement has lapsed, so the social_public and print_for_sale it lists clears nothing.

### ALTERATION_DISCLOSURE_MISSING — 3 request(s)

- REQ-05 substantively alters a person's appearance for social_public with no disclosure on file.
- REQ-23 substantively alters a person's appearance for print_for_sale with no disclosure on file.
- REQ-30 substantively alters a person's appearance for print_for_sale with no disclosure on file.

## What the policy clears

**The personal-use allowance (§3).** REQ-01, REQ-22, REQ-32 composite a licensed persona and are
logged `personal_only`, so §3 clears them on the allowance alone, whatever the
register says. The allowance releases §3 and nothing else: REQ-32 still carries
`MISSING_MINOR_CONSENT`, and REQ-04 and REQ-19 are still
`THIRD_PARTY_BACKGROUND_UNLICENSED` on personal-only requests.

**Licences that do reach their request.** LIC-102 expires on 2026-03-31 — the
audit date itself — so it is still current, and REQ-02 and REQ-27 raise no
character finding; both are flagged only for routing. REQ-09 runs Ember Knight
under LIC-104, which names `print_for_sale`, so it is clean where REQ-10 — the
same property at `social_public` — is not.

**Requests that look loaded and are clean.** REQ-06 carries a licensed persona, a
public channel and a substantive alteration, and clears all three: LIC-101 names
`social_public`, ACC-02's active agreement covers that channel, and the
disclosure is on file. REQ-11's `publicity` consent expires on 2026-03-31 and is
therefore current. REQ-12 and REQ-07 are `client_internal`, which is neither
public nor paid and never routes; REQ-07's substantive alteration owes no
disclosure at that distribution. REQ-24 and REQ-26 alter substantively for
`personal_only` and owe none either. REQ-28's `basic` consent reaches
`personal_only` and its background licence LIC-105 covers `all`.

**Licences that lapsed before the audit date.** LIC-103 (Rook and Raven) ended
2026-03-30, one day short, and LIC-106 (Aurora Ridge Panorama) ended 2026-02-28.
Both are in the register and neither clears anything: LIC-103 leaves REQ-05
unlicensed for character use, LIC-106 leaves REQ-05 and REQ-19 unlicensed for
background.

## Accounts whose master agreement has lapsed

- **ACC-04 (Birchwood School Yearbook)** — a `studio_partner` account listing `social_public`, but the agreement has lapsed. A
  lapsed agreement covers nothing, so its public and paid requests route like
  any uncovered account's: REQ-13, REQ-14.
- **ACC-08 (Ridgeway Sports Club)** — a `press_agency` account listing `social_public;print_for_sale`, but the agreement has lapsed. A
  lapsed agreement covers nothing, so its public and paid requests route like
  any uncovered account's: REQ-29, REQ-30.

Account type does not clear a channel by itself: ACC-08 is a `press_agency` and
routes exactly as consumer account ACC-07 does.

## Escalation (§8)

- **ACC-01 — ESCALATION_REQUIRED.** 2 of its 4 requests carry a finding.
- **ACC-02 — ESCALATION_REQUIRED.** only 1 request is flagged, but that request carries 4 findings.
- **ACC-03 — none.** 1 flagged request, carrying 2 finding(s): neither limb of §8 is met.
- **ACC-04 — ESCALATION_REQUIRED.** 3 of its 4 requests carry a finding.
- **ACC-05 — ESCALATION_REQUIRED.** 3 of its 4 requests carry a finding.
- **ACC-06 — ESCALATION_REQUIRED.** 2 of its 4 requests carry a finding, and one carries 3.
- **ACC-07 — none.** 1 flagged request, carrying 1 finding(s): neither limb of §8 is met.
- **ACC-08 — ESCALATION_REQUIRED.** 3 of its 4 requests carry a finding.

Escalation is a property of the account. It is not a finding against any request,
and it is counted from this audit rather than taken from elsewhere.
