# QC report card

Task: obi/gen-g780-realestate-fairhousing-collateral-audit
Run: internal-3f38d2e2 (internal)
Generated: 2026-08-19T13:33:01.107Z

## QC script (advisory)
- Gate: **FAIL** — 3 blocking
- Findings: 3 high, 2 medium, 8 low
- GLM semantic audit: ok — 1 accepted issue(s)

## Reviewer (governs)
- Decision: **none yet**
- Checklist: 1/66 answered, 0 item(s) flagged for a closer look
- Verifiers: 0 reviewed, 0 to fix

## Outcome
no reviewer decision yet
