# Reviewer worksheet

Task: obi/gen-g780-realestate-fairhousing-collateral-audit
Updated: 2026-08-19T15:44:51.515Z

## Step 1 — the prompt

- **yes** — Does every file, folder, and tool named in the prompt really exist?
- **yes** — Does each file hold the data the prompt says it holds?
- **yes** — Can the model find everything it needs in the prompt and the files?
- **yes** — Could a skilled person finish this task with only these files?
- **yes** — Does the task need several steps and real thinking? (One search or one command is not enough.)
- **yes** — Does it ask for work this kind of user really needs?
- **yes** — Does it sound like a message a person typed, not a test written for a machine?
- **yes** — Does it look like the real user prompts we started from?
- **no** — Does the prompt explain how to do the work step by step? (It should say what the user wants, not how.)
- **no** — Does the prompt give exact file names, numbers, or words that only help the verifiers pass?
## Step 2 — the verifiers

- **—** — Your own checks — before you see the manifest
- **reviewed** — verifier audit_exists
- **reviewed** — verifier memo_exists
- **reviewed** — verifier results_exists
- **reviewed** — verifier audit_header_exact
- **reviewed** — verifier audit_no_extra_columns
- **—** — verifier row_sec01
- **reviewed** — verifier row_sec02
- **reviewed** — verifier row_sec03
- **reviewed** — verifier row_sec04
- **reviewed** — verifier row_sec05
- **reviewed** — verifier row_sec06
- **reviewed** — verifier row_sec07
- **reviewed** — verifier row_sec08
- **reviewed** — verifier row_sec09
- **reviewed** — verifier row_sec10
- **reviewed** — verifier row_sec11
- **reviewed** — verifier row_sec12
- **reviewed** — verifier row_sec13
- **reviewed** — verifier row_sec14
- **reviewed** — verifier row_sec15
- **reviewed** — verifier row_sec16
- **reviewed** — verifier row_sec17
- **reviewed** — verifier row_sec18
- **reviewed** — verifier row_sec19
- **reviewed** — verifier row_sec20
- **reviewed** — verifier row_sec21
- **reviewed** — verifier row_sec22
- **reviewed** — verifier row_sec23
- **reviewed** — verifier row_sec24
- **reviewed** — verifier row_sec25
- **reviewed** — verifier row_sec26
- **reviewed** — verifier row_sec27
- **reviewed** — verifier row_sec28
- **reviewed** — verifier row_sec29
- **reviewed** — verifier row_sec30
- **reviewed** — verifier sec10_carries_no_violation_label
- **reviewed** — verifier sec13_carries_no_violation_label
- **reviewed** — verifier memo_explains_narrative
- **reviewed** — verifier memo_explains_protected
- **reviewed** — verifier memo_explains_disclaimer
- **reviewed** — verifier memo_states_amended_class_list
- **reviewed** — verifier result_section_count
- **reviewed** — verifier result_flagged_count
- **reviewed** — verifier result_personal_narrative_count
- **reviewed** — verifier result_protected_lang_count
- **reviewed** — verifier result_disclaimer_missing_count
- **none
30 row checks cover every section, two negative guards cover the compliant-** — Coverage gap
## Step 2 — the verifier set

- **yes** — Do the verifiers cover everything the prompt asks for?
- **no** — Do they check anything the prompt does not ask for?
- **yes** — Will they pass good work and fail bad work?
- **yes** — Will they give the same score every time? (No dates, no live web, no random order.)
## Step 3 — the run

- **0** — trajectory mistakes recorded
- **yes** — Are all the mistakes the model's fault?
- **no** — Does GLM-5.2 succeed less than 50% of the time?
  - note:  GLM-5.2 passed 5 of 5. Individual rewards 1, 1, 1, 1, 1 — 5 trials, 0 exceptions — in evaluations/glm-5.2/r1..r5/verifier/reward.txt, each with 0 failed verifiers in test-stdout.txt. Success rate is 100%, not below 50%. ▎ ▎ This is not a defect in the task: Oracle scores 1.0 on all 46 verifiers and the five stability repeats are identical. The task is sound and simply too easy for GLM-5.2. Recorded as too easy in the tracker per delivery guidance, keeping the row, rather than Fix or Reject.
## Final decision

- **Accept** — final decision
  - note: The grading is good . Oracle scored 1.0 across all of the 46 verifiers, and all the 5 stability repeats in the evaluations/stability/ return identical per-item verdicts, every check is deterministic and no judge is involved, so the result is reproducible. GLM 5.2 passes 5/5 ( we can see that in evaluations/glm-5.2/r1..r5/verifier/reward.txt) 0 exceptions, which makes this too easy rather than broken: that is recorded as a tracker status, not a QC rejection. E3 is the only open finding and cannot be awarded while every run passes

## Decision: Accept
The grading is good . Oracle scored 1.0 across all of the 46 verifiers, and all the 5 stability repeats in the evaluations/stability/ return identical per-item verdicts, every check is deterministic and no judge is involved, so the result is reproducible. GLM 5.2 passes 5/5 ( we can see that in evaluations/glm-5.2/r1..r5/verifier/reward.txt) 0 exceptions, which makes this too easy rather than broken: that is recorded as a tracker status, not a QC rejection. E3 is the only open finding and cannot be awarded while every run passes
