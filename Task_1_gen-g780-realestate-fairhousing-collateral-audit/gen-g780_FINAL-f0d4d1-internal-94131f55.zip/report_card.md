# QC report card

Task: obi/gen-g780-realestate-fairhousing-collateral-audit
Run: internal-94131f55 (internal)
Generated: 2026-08-19T15:45:03.628Z

## QC script (advisory)
- Gate: **FAIL** — 2 blocking
- Findings: 3 high, 2 medium, 4 low
- GLM semantic audit: ok — 3 accepted issue(s)

## Reviewer (governs)
- Decision: **Accept** — The grading is good . Oracle scored 1.0 across all of the 46 verifiers, and all the 5 stability repeats in the evaluations/stability/ return identical per-item verdicts, every check is deterministic and no judge is involved, so the result is reproducible. GLM 5.2 passes 5/5 ( we can see that in evaluations/glm-5.2/r1..r5/verifier/reward.txt) 0 exceptions, which makes this too easy rather than broken: that is recorded as a tracker status, not a QC rejection. E3 is the only open finding and cannot be awarded while every run passes
- Checklist: 19/66 answered, 1 item(s) flagged for a closer look
- Verifiers: 45 reviewed, 0 to fix

## Outcome
the deterministic gate is FAIL — blocking findings cannot be overridden by a reviewer Accept; fix or hand back
